#!perl


########################################################################################################
######################################## PARSE QUESTIONAIRE LOGIC ######################################
########################################################################################################

########################### PROCESS SAMPLE.pl ###########################
#DESCRIPTION: Breaks Provided text into a logic tree - flags 
#TODO:
#CHANGE LOG:

package QuestionaireExportTemplate;

use warnings;
use strict;
use Data::Dumper;
use Development::BuildSurvey::QuestionaireMisc;

# LANG STRUCTURE

# CONCAT
# OBJECT + OBJECT

# OBJECT
#	TEXT
#	CONDITION
#	LOOP
#	INSERTION

#CONDITION
#	[[CONCAT]]:TEXT

#LOOP
#	{{CONCAT}}:TEXT

#ID
# <<TEXT>>

#TEXT

#VALID IDENTIES
#LOOPS 

#

########################################################################################################
###################################### CONSTANTS AND GLOBALS ###########################################
########################################################################################################
my %KeyTwoChar=(	#KEY TWO CHARACTER STRINGS RESERVED BY PROCESSING
	"<<"=>201,
	">>"=>202,
	"[["=>203,
	"{{"=>204,
	#"##"=>205,
);

my %KeyThreeChar=( #KEY THREE CHARACTER STRINGS RESERVED BY PROCESSING
	"]]:"=>301,
	"}}:"=>302,
);

use constant TOKEN_TEXT 		   	=> 1000;
use constant TOKEN_IDENTITY_START  	=> 1201;
use constant TOKEN_IDENTITY_END    	=> 1202;
use constant TOKEN_CONDITION_START 	=> 1203;
use constant TOKEN_CONDITION_END	=> 1301;
use constant TOKEN_LOOP_START 	   	=> 1204;
use constant TOKEN_LOOP_END 	   	=> 1302;
#use constant TOKEN_COMMENT			=> 1205;

use constant TOKEN_STRUCT_ID		=>0;
use constant TOKEN_STRUCT_TEXT		=>1;

use constant NODE_STRUCT_ID				=>0;
use constant NODE_STRUCT_TEXT           =>1;
use constant NODE_STRUCT_LEFT_CHILD     =>2;
use constant NODE_STRUCT_RIGHT_CHILD   	=>3;

use constant NODE_CONCATENATE	=> 10000;
use constant NODE_TEXT			=> 10001;
use constant NODE_LOOP			=> 10002;
use constant NODE_CONDITION		=> 10003;
use constant NODE_IDENTIFIER	=> 10004;


########################################################################################################
########################################## SECONDARY FUNCTIONS #########################################
########################################################################################################
############# SurveySetup:AddToken #############
#FUNCTION:   Builds a Token structure
#PARAMATERS: ID, Text
#RETURNS:	 Token
sub AddToken{
	my $TokenId = $_[0];			#ID OF THE TOKEN
	my $TokenText = $_[1];			#TEXT OF THE TOKEN
	my @NewToken;						#TOKEN STRUCTURE
	
	$NewToken[TOKEN_STRUCT_ID]=$TokenId;
	$NewToken[TOKEN_STRUCT_TEXT]=$TokenText;
	
	return (\@NewToken);
}
########################################################################################################
####################################### MAIN PROCESSING FUNCTIONS ######################################
########################################################################################################

############# SurveySetup:Lex #############
#FUNCTION:   Deletes processing data structures and tags cleaning up the structure for future use
#PARAMATERS: Text to be processed
#RETURNS:	 List of Tokens
sub __Lex{
	my $Text = $_[0];	#TEXT BEING PROCESSED
	my @Tokens;			#LIST OF TOKENS GENERATED					
	
	#THESE COMMANDS PROVIED CONTROL OVER NEWLINES
	#REMOVE NEW LINE CHARACTERS
	$Text =~ s/\n//g;
	#REPLACE \N WITH NEW LINE CHARACTER	
	$Text =~ s/\\n/\n/g;
	
	#CONTINUE TO LOOK UNTIL ALL TEXT HAS BEEN PROCESSED
	while ($Text=~ /\S/){	
		#CHECK FOR A BLOCK OF ALPHA_NUMERIC
		if($Text =~ /^([0-9a-z_]+)/i){
			#ADD NEW TOKEN
			push (@Tokens, AddToken(TOKEN_TEXT, $1));
			#REMOVE ASSOCIATE TEXT
			$Text =~ s/^([0-9a-z_]+)//i;		
		}
		#CHECK FOR SPACE
		elsif($Text =~ /^(\s+)/i){
			#ADD NEW TOKEN
			push (@Tokens, AddToken(TOKEN_TEXT, $1));
			#REMOVE ASSOCIATE TEXT
			$Text =~ s/^(\s+)//i;		
		}
		#CHECK FOR A THREE CHARACTER BLOCK
		elsif(exists($KeyThreeChar{substr($Text,0,3)})){
			push (@Tokens, AddToken($KeyThreeChar{substr($Text,0,3)}+1000, ""));
			$Text = substr($Text, 3);
		}
		#CHECK FOR A TWO CHARACTER BLOCK
		elsif(exists($KeyTwoChar{substr($Text,0,2)})){
			push (@Tokens, AddToken($KeyTwoChar{substr($Text,0,2)}+1000, ""));
			$Text = substr($Text, 2);
		}
		#ADD NEXT CHARACTER AS TEXT
		else {
			push (@Tokens, AddToken(TOKEN_TEXT, substr($Text,0,1)));
			$Text = substr($Text, 1);
		}
	
	}
	
	return (\@Tokens);
}

############# SurveySetup:Parse #############
#FUNCTION:   Takes provided token list and build a binary execution tree
#PARAMATERS: List of Tokens
#RETURNS:	 Tree Node
sub __Parse{
	my $Tokens = $_[0];			#TOKENS
	my @NewNode;				#NEW NODE GENERATE BY THIS PROCESS
	my $LeftChild;				#LEFT CHILD TO CURRENT NODE
	my $RightChild;				#RIGHT CHILD TO CURRENT NODE
	my $InitialPass = $_[1]; 	#FLAG DENOTING THAT THIS IS THE FIRST INSTANCE IN TEH LOOP THAT THIS FUNCTION HAS BEEN CALLED
	my $FileName = $_[2];		#FILE BEIGN PROCESSED
	
	#CHECK FOR LOOP
	if ($Tokens->[0]->[TOKEN_STRUCT_ID] == TOKEN_LOOP_START){
		#REMOVE FIRST ELEMENT
		shift(@$Tokens); 
		#GET TEXT IN LOOP
		my $ContentNode = __Parse($Tokens,0, $FileName);
		#CHECK FOR AND REMOVE ELEMENT
		die "$FileName - TEMPLATE SYNTAX ERROR - CAN'T FIND END OF LOOP " if($Tokens->[0]->[TOKEN_STRUCT_ID] != TOKEN_LOOP_END);
		shift(@$Tokens); 
		#CHECK FOR AND BUILD IDENTIFIER
		die "$FileName - TEMPLATE SYNTAX ERROR - CAN'T FIND IDENTIFIER " if($Tokens->[0]->[TOKEN_STRUCT_ID] != TOKEN_TEXT);
		my @IDNode; 	#ID NODE
		$IDNode[NODE_STRUCT_ID]=NODE_TEXT;
		$IDNode[NODE_STRUCT_TEXT]=$Tokens->[0]->[TOKEN_STRUCT_TEXT];
		shift(@$Tokens); 
		#SET UP LOOP NODE
		my @LoopNode; 	#LOOP NODE
		$LoopNode[NODE_STRUCT_ID]=NODE_LOOP;		
		$LoopNode[NODE_STRUCT_LEFT_CHILD]=$ContentNode;
		$LoopNode[NODE_STRUCT_RIGHT_CHILD]=\@IDNode;		
		$LeftChild = \@LoopNode;
	}
	#CHECK FOR CONDITION
	elsif($Tokens->[0]->[TOKEN_STRUCT_ID] == TOKEN_CONDITION_START){
		#REMOVE FIRST ELEMENT
		shift(@$Tokens); 
		#GET TEXT IN LOOP
		my $ContentNode = __Parse($Tokens, $FileName);
		#CHECK FOR AND REMOVE ELEMENT
		die "$FileName - TEMPLATE SYNTAX ERROR - CAN'T FIND END OF CONDITION " if($Tokens->[0]->[TOKEN_STRUCT_ID] != TOKEN_CONDITION_END);
		shift(@$Tokens); 
		#CHECK FOR AND BUILD IDENTIFIER
		die "$FileName - TEMPLATE SYNTAX ERROR - CAN'T FIND IDENTIFIER " if($Tokens->[0]->[TOKEN_STRUCT_ID] != TOKEN_TEXT);
		my @IDNode; 	#ID NODE
		$IDNode[NODE_STRUCT_ID]=NODE_TEXT;
		$IDNode[NODE_STRUCT_TEXT]=$Tokens->[0]->[TOKEN_STRUCT_TEXT];
		shift(@$Tokens); 
		#SET UP CONDITION NODE
		my @ConditionNode; 	#LOOP NODE
		$ConditionNode[NODE_STRUCT_ID]=NODE_CONDITION;		
		$ConditionNode[NODE_STRUCT_RIGHT_CHILD]=\@IDNode;		
		$ConditionNode[NODE_STRUCT_LEFT_CHILD]=$ContentNode;		
		$LeftChild = \@ConditionNode;
	}
	elsif($Tokens->[0]->[TOKEN_STRUCT_ID] == TOKEN_IDENTITY_START){
		#REMOVE FIRST ELEMENT
		shift(@$Tokens); 
		#BUILD IDENTITY NODE
		my @IdentityNode; 	#IDENTITY NODE
		$IdentityNode[NODE_STRUCT_ID]=NODE_IDENTIFIER;
		#CHECK FOR AND BUILD IDENTIFIER
		die "TEMPLATE SYNTAX ERROR - CAN'T FIND IDENTIFIER " if($Tokens->[0]->[TOKEN_STRUCT_ID] != TOKEN_TEXT);
		$IdentityNode[NODE_STRUCT_TEXT]=$Tokens->[0]->[TOKEN_STRUCT_TEXT];
		shift(@$Tokens); 		
		#print Dumper $Tokens;
		die "$FileName - TEMPLATE SYNTAX ERROR - CAN'T FIND END OF IDENTITY" if($Tokens->[0]->[TOKEN_STRUCT_ID] != TOKEN_IDENTITY_END);
		shift(@$Tokens); 
		$LeftChild = \@IdentityNode;
	}
	elsif($Tokens->[0]->[TOKEN_STRUCT_ID] == TOKEN_TEXT){
		my @IdentityNode; 	#IDENTITY NODE
		$IdentityNode[NODE_STRUCT_ID]=NODE_TEXT;
		$IdentityNode[NODE_STRUCT_TEXT]="";
		#LOOP UNTIL NO MORE TOKENS OR ENCOUNTER A 
		while( scalar(@$Tokens)>0 && $Tokens->[0]->[TOKEN_STRUCT_ID] == TOKEN_TEXT){
			$IdentityNode[NODE_STRUCT_TEXT] .= $Tokens->[0]->[TOKEN_STRUCT_TEXT];
			shift(@$Tokens); 
		}
		$LeftChild = \@IdentityNode;
	}
	elsif($InitialPass && $Tokens->[0]->[TOKEN_STRUCT_ID] == TOKEN_IDENTITY_END){
		die "$FileName - End of loop identifier detected, withouth matching start\n";
	}
	elsif($InitialPass && $Tokens->[0]->[TOKEN_STRUCT_ID] == TOKEN_CONDITION_END){ 
		die "$FileName - End of loop identifier detected, withouth matching start\n";
	}
	elsif($InitialPass && $Tokens->[0]->[TOKEN_STRUCT_ID] == TOKEN_LOOP_END ){
		die "$FileName - End of loop identifier detected, withouth matching start\n";
	}
	
	#PARSE TO BUILD RIGHT SIDE OF CONCATENATE NODE IF MORE TOKENS TO PROCESS
	if (scalar(@$Tokens)>0 && $Tokens->[0]->[TOKEN_STRUCT_ID] != TOKEN_IDENTITY_END && $Tokens->[0]->[TOKEN_STRUCT_ID] != TOKEN_CONDITION_END && $Tokens->[0]->[TOKEN_STRUCT_ID] != TOKEN_LOOP_END){
		$RightChild = __Parse($Tokens, 0, $FileName);
		#BUILD CONCATENATION NODE
		my @ConcatNode; 	#CONCATENATION NODE
		$ConcatNode[NODE_STRUCT_ID]=NODE_CONCATENATE;
		$ConcatNode[NODE_STRUCT_RIGHT_CHILD]=$RightChild;
		$ConcatNode[NODE_STRUCT_LEFT_CHILD]=$LeftChild;
		return (\@ConcatNode)
	}
	#RETURN LEFT CHILD IF NO MORE TOKENS
	else {
		return $LeftChild;
	}
}

############# SurveySetup:ProcessNode #############
#FUNCTION:   Runs the saved binary execution tree and runs it sourcing data from the provided Question structure
#PARAMATERS: Tree Node, Question Structure
#RETURNS:	 Text
sub __ProcessNode{
	my $Node = $_[0];				#STRUCTURE NODE
	my $Question = $_[1];			#QUESTION STRUCTURE
	my $ListIndex = -1;				#INDEX PASSED IF EXECUTED WITHIN A LOOP TO TRACK LOOPING INDEX
	$ListIndex = $_[2] if (scalar(@_)>2);	
	#PROCESS CURRENT NOD EIF CONCATENATE
	if($Node->[NODE_STRUCT_ID] == NODE_CONCATENATE){
		return __ProcessNode($Node->[NODE_STRUCT_LEFT_CHILD], $Question,$ListIndex).__ProcessNode($Node->[NODE_STRUCT_RIGHT_CHILD], $Question,$ListIndex);
	}	
	#IF TEXT NODE RETURN TEXT STORED
	elsif($Node->[NODE_STRUCT_ID] == NODE_TEXT){
		return $Node->[NODE_STRUCT_TEXT];
	}			
	#PROCESS IF LOOP
	elsif($Node->[NODE_STRUCT_ID] == NODE_LOOP){	
		my $Identifier = $Question->GetIdentifierValue($Node->[NODE_STRUCT_RIGHT_CHILD]->[NODE_STRUCT_TEXT],$ListIndex);		
		my $Result = "";		#	RETURN FROM LOOP
		#CHECK IF RETURNED STRUCTURE IS AN ARRAY		
		if (ref($Identifier) eq 'ARRAY'){			
			#LOOP THROUGH PROVIDED ARRAY CALLING EACH LINE INTO THE LEFT SIDE OF THE TREE
			for (my $Index=0; $Index < scalar(@$Identifier); $Index++){		
				$Result .= (__ProcessNode($Node->[NODE_STRUCT_LEFT_CHILD], $Question,$Index));
			}
		}
		return $Result;
	}
	#PROCESS IF CONDITION
	elsif($Node->[NODE_STRUCT_ID] == NODE_CONDITION){
		my $Identifier = $Question->GetIdentifierValue($Node->[NODE_STRUCT_RIGHT_CHILD]->[NODE_STRUCT_TEXT],$ListIndex);
		#CHECK IF VALUE OF IDENTIFIER IS VALID
		if (defined ($Identifier) &&((ref($Identifier) eq 'ARRAY' && scalar(@$Identifier)>0) || $Identifier=~/[1-9a-z]/i)){
			return (__ProcessNode($Node->[NODE_STRUCT_LEFT_CHILD], $Question,$ListIndex));
		}
		else {
			return '';
		}
	}		
	#IF IDENTIFIER CALL THE QUESTION WITH THE ID AND RETURN
	elsif($Node->[NODE_STRUCT_ID] == NODE_IDENTIFIER){

		return $Question->GetIdentifierValue($Node->[NODE_STRUCT_TEXT],$ListIndex);
	}	
	
	
}

########################################################################################################
############################################## CONSTRUCTOR #############################################
########################################################################################################
############# SurveySetupLogic:New #############
#FUNCTION:   Object Constructor - Builds a SurveySetupLogic object, breaks down provided text into tree(s) and generates flags
#PARAMATERS: Logic Text
#RETURNS:	 Nothing
sub New {
    my $Class = shift();		#CLASS
    my $Self = {
		FILE_NAME => shift(),		#TEXT TO BE PROCESSED
    };	
	bless $Self, $Class;	
	#READ FILE
	local $/;
	open my $FileHandle, '<', $Self->{FILE_NAME} or die "Can't open $Self->{FILE_NAME}: $!";
    $Self->{TEXT} = <$FileHandle>;	
	close $FileHandle;
	#PARSE TEXT INTO TREE
	$Self->{TREE}=__Parse(__Lex($Self->{TEXT}),1,$Self->{FILE_NAME});
	#CLEAR TEXT:
	$Self->{TEXT}='';
    return $Self;
}

########################################################################################################
########################################### EXTERNAL FUNCTIONS #########################################
########################################################################################################

############# SurveySetup:Export #############
#FUNCTION:   Runs the saved binary execution tree and runs it sourcing data from the provided Question structure
#PARAMATERS: Question Structure
#RETURNS:	 Question Text
sub Export {
	my $Self = $_[0];				#CLASS VARIABLE	
	
	my $Question = $_[1];			#QUESTION STRUCTURE
	my $ReturnText = "";			#TEXT RETURNED FROM PROCESSING
	
	$ReturnText = __ProcessNode($Self->{TREE}, $Question);
	
	#$ReturnText =~ s/\n\s*\n/\n/g; #REMOVE ANY BLANK LINES - REMOVED 
	$ReturnText ="\n".$ReturnText ."\n"; #ADD A SPACE TO THE BEGINING AND END OF THE OUTPUT
	
	return ($ReturnText);
	
}
1;