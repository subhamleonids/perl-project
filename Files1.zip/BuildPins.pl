#!perl
use warnings;
use strict;
use Data::Dumper;
use Try::Tiny;
use utf8;
use open IO => ':utf8';
use JSON;
use MIME::Base64;
use REST::Client;

use Development::BuildSurvey::CheckJSON;

########################################################################################################
############################################# BUILD PINS #############################################
########################################################################################################
#DESCRIPTION: Provided a content JSON file, to establish study path, and file name generates a pin file and uploads it, then generates a link file to upload to Zamplia
#PARAMATERS:Content File

#CHARACTER LIST
my @Char = ('a','b','c','d','e','f','g','h','i','j','k','l','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z','A','B','C','D','E','F','G','H','I','J','K','L','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','0','1','2','3','4','5','6','7','8','9','0','1','2','3','4','5','6','7','8','9','0','1','2','3','4','5','6','7','8','9','0','1','2','3','4','5','6','7','8','9','0','1','2','3','4','5','6','7','8','9','0','1','2','3','4','5','6','7','8','9','0','1','2','3','4','5','6','7','8','9','0','1','2','3','4','5','6','7','8','9','0','1','2','3','4','5','6','7','8','9','0','1','2','3','4','5','6','7','8','9');


my $Host = 'https://logit.decipherinc.com/';									  #MAIN HOST FOR ULOAD
my $APIKey =  'wbgxmsbbep9dp93t8kb12kbde7x625g995wwgk6vhd0d6uv1ntpdb4mfnvj1umtm'; #API KEY FOR UPLOAD

my $OutputPath = 'K:/Programs/Development/BuildSurvey/Output/';    					#PATH TO SAVE OUTPUT FILES

my $ContentFileName;					#ILE NAME FOR THE PROVIDED CONTENT JSON
my $PinFileName;						#FILE NAME FOR THE PIN FILE
my $LinkFileName;						#FILE NAME FOR THE LINK FILE

my $Path;								#PATH FROM CONTENT FILE FOR UPLOADS
my $ProjectName;						#PROJECT NAME FROM UPLOADS

my $Content;							#CONTENT DATA STRUCUTRE
my %PinsUsed;							#STRCTURE USED TO TRACK PINS USED

my $NumCases =100000;					#NUMBER OF CASES GENERATED

my $Date;								#CURRENT DATE

my $PinText="";							#Text of the pin list for upload

########################################################################################################
########################################## SECONDARY FUNCTIONS #########################################
########################################################################################################
############# Parse JSON #############
#FUNCTION:   Provided a JSON file parses it into it's defined structure 
#PARAMATERS: JSON File
#RETURNS:	 JSON Structure
sub ParseJSON{
	my $JSONFile = $_[0];			#FILE NAME TO PROCESS
	
	#VERIFY JSON FILE SYNTAXT
	try{
		my $CheckJSONObject = New CheckJSON($JSONFile);
	}
	catch{
		die($_);		
	};
	
	my $FileText = do {
	   open(my $JSONFileHandle, "<:encoding(UTF-8)", $JSONFile) or die("Can't open \"$JSONFile\": $!\n");
	   local $/;
	   <$JSONFileHandle>
	};

	my $JSON = JSON->new;
	my $Structure = $JSON->decode($FileText);	
	
	return $Structure;
}


########################################################################################################
########################################## MAIN FUNCTION  ##############################################
########################################################################################################


#my $StructureFileName = "Templates/Hotspex_Control.json";
#my $ContentFileName =  "Test_Content.json";

#CHECK FOR VALID PARAMATERS
if (scalar(@ARGV) < 1){

	print "USAGE: BuildPins.pl Content File";		
	exit();
}

$ContentFileName = shift(@ARGV);

#CURRENT DATE
my @Date = localtime();
$Date =$Date[3];
$Date = '0'.$Date if (($Date[3]) < 10);
$Date =($Date[4]+1).$Date; 
$Date = '0'.$Date if (($Date[4]+1) < 10);
$Date = ($Date[5]+1900).$Date;

#PARSE JSON CONTENT
try{
	$Content = ParseJSON($ContentFileName);
}
catch {
	die($_."\nFAILED TO PARSE JSCON CONFIG\n");
};

$Path = $Content->{'PATH'};
$ProjectName = $Content->{'HPROJECTNAME'};

#CLEAN LEADING PATH inf
$Path =~ s/^\/?api//;
$Path =~ s/^\/?v1//;
$Path =~ s/^\/?surveys//;
$Path =~ s/^\/?selfserve//;
$Path =~ s/^\/?53b//;
$Path =~ s/^\///;

#CLEAN TRAILING - ANYTHIGN AFTER A /
$Path =~ s/\/.*$//;

$PinFileName=$Date."_".$ProjectName."_"."PINS.txt";
$LinkFileName=$Date."_".$ProjectName."_"."LINKS.txt";

#BUILD PIN LIST
open (PIN_OUTPUT_FILE, "> ".$OutputPath.$PinFileName) or die "Could not open file $PinFileName"; 
open (LINK_OUTPUT_FILE, "> ".$OutputPath.$LinkFileName) or die "Could not open file $LinkFileName"; 
#GENERATE PINS
my $PinsGenerated =0;					#COUNTER OF NUMBER OF CASES GENERATED
while ($PinsGenerated < $NumCases){
	my $NewPin ="";		#NEW PINS GENERATED
	for (my $CharCount=0; $CharCount < 9; $CharCount++){		
		$NewPin .= $Char[int(rand(scalar(@Char)))];
	}
	#CHECK VALIDITIY - CHECK FOR LETTER + NUMBER
	my $NumAlpha = () = $NewPin =~ /[A-Z]/gi;
	if ($NewPin =~ /[0-9]/ && $NumAlpha > 1){
		#CHECK FOR LEADING ZERO IF FLAG ADDED. 
		if($NewPin !~ /^0/){
			#CONFIRM PIN HAS NOT ALREADY BEEN USED
			if (!(exists($PinsUsed{uc($NewPin)}))){
				$PinsGenerated++;
				$PinsUsed{uc($NewPin)}=1;
				print PIN_OUTPUT_FILE $NewPin."\n";
				print LINK_OUTPUT_FILE 'https://logit.decipherinc.com/survey/selfserve/53b/'.$Path.'?list=101&UID=$UID&QVENDOR=$QVENDOR&PIN='.$NewPin."\n";
				$PinText .= $NewPin."\n";
			}	
		}
	}
}
close (PIN_OUTPUT_FILE);
close (LINK_OUTPUT_FILE);

#UPLOAD PINS AS .DAT TO SPECIFIED STUDY
#CHECK IF JSON CONTAINS PATH - UPLOAD IF PRESENT
if (exists($Content->{"PATH"}) && $Content->{"PATH"}=~ /[a-z0-9]/i){
	
	#INITIALIZE API OBJECT
	my $Client = REST::Client->new();
	$Client->setHost($Host);
	$Client->addHeader('x-apikey', $APIKey );

	my $UploadJSON = encode_json {  #JSON DATA STRCUTRE
	contents => $PinText, 
	validate  => "false",  
	overwriteLive  => "false",  
	location  => "root"
	}; 

	$Client->PUT('/api/v1/surveys/selfserve/53b/'.$Path.'/files/uniquePINS.dat', $UploadJSON,{"Content-Type"=>"application/json"});

}




#UPLOAD LINK FILE

