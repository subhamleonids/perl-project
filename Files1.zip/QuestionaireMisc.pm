#!perl


########################################################################################################
########################################## QUESTIONAIRE MISC #######################################
########################################################################################################
#DESCRIPTION: Miscellaneous functions used to process questionnaires
#TODO:
#CHANGE LOG:
package QuestionaireMisc;

use warnings;
use strict;
use Data::Dumper;

#INDEX FOR FORMATTING ARRAYS
use constant FORMAT_INDEX_SQ_BRK   	=> 0;
use constant FORMAT_INDEX_CRLY_BRK 	=> 1; 
use constant FORMAT_INDEX_BOLD     	=> 2;	
use constant FORMAT_INDEX_ITTALIC 	=> 3; 
use constant FORMAT_INDEX_UNDERLINE => 4; 
use constant FORMAT_INDEX_ALL_CAP  	=> 5;

our @FormatHash = ( #LIST OF CHARACTERS USED TO BUILD HASH
	'SQ',
	'CRL',	
	'B',
	'I',
	'U',
	'CAP'
);


our %Delimiters=( #LIST OF CHARACTERS WHICH DELIMIT TEXT
	'('=> 1,
	'['=> 2,
	'{'=> 3,
	'<'=> 4,
	'<<B>>'=> 5,
	'<<I>>'=> 6,
	'<<U>>'=> 7,
	')'=> 11,
	']'=> 12,	
	'}'=> 13,	
	'>'=> 14,	
	'<</B>>'=> 15,
	'<</I>>'=> 16,
	'<</U>>'=> 17,
	'<<T>>'=> 20,
);



############# SurveySetup:ConvertNumToID #############
#FUNCTION:   Converts Alphabetical ids to numeric equivalent, otherwise strips all non-numeric
#PARAMATERS: Number A-1 B-2 C-3 ... Z-26 AA-27 AB-28
#RETURNS:	 Alpha ID
sub ConvertNumToID{
	my $Num = $_[0];		#NUMBER
	my $Dividend = $Num;	#DIVIDEND FOR CALCULATION
    my $Return =  "";		#RETURN STRING
    my $Modulo;				#MODULO FOR CALCULATION

	#CHECK THAT THERE ARE NO LETTERS PRESENT IN NUM
	if($Dividend !~ /[a-z]/i){
		while ($Dividend > 0)
		{
			$Modulo = ($Dividend - 1) % 26;
			$Return = chr(65 + $Modulo) . $Return;
			$Dividend = int(($Dividend - $Modulo) / 26);
		} 
	}
    return $Return;
}

############# SurveySetup:ConvertIDtoNum #############
#FUNCTION:   Converts Alphabetical ids to numeric equivalent, otherwise strips all non-numeric
#PARAMATERS: Text
#RETURNS:	 Updated ID
sub ConvertIDToNum{
	my $ID = $_[0];		#ID INPUT
	
	#CHECK IF ID IS ONLY COMPOSED OF LETTERS
	if($ID =~ /[A-Z]+/i){
		my $Return=0;
		my @Letters = split(//,$ID);
		#LOOP THROUGH EACH LETTER
		foreach my $Letter (@Letters ){
			$Return=$Return*26+(ord($Letter)-64);
		}
		return($Return);
	}	
	#CHECK IF ID IS BLANK
	return 0 if($ID eq "") ;
	$ID =~ s/[^0-9]//g; #REMOVE NON-NUMERIC
	return ($ID)
}

############# SurveySetup:Clear Format Tags #############
#FUNCTION:   Removes Formatting tags left in the survey
#PARAMATERS: Text
#RETURNS:	 Updated text
sub ClearFormatTags{
	my $Text = $_[0]; #TEXT TO BE PROCESSED
	if (defined ($Text)){
		$Text =~ s/<<\/?B>>//gi;
		$Text =~ s/<<\/?I>>//gi;
		$Text =~ s/<<\/?U>>//gi;
		$Text =~ s/<<T>>//gi;
	}
	$Text =~ s/^\s+//g;
	$Text =~ s/\s+$//g;
	return ($Text);
}

############# SurveySetup:Clear Tags #############
#FUNCTION:   Removes tags left in the survey
#PARAMATERS: Text
#RETURNS:	 Updated text
sub ClearTags{
	my $Text = $_[0]; #TEXT TO BE PROCESSED
	if (defined($Text)){
		$Text =~ s/<<\/?B>>//gi;
		$Text =~ s/<<\/?I>>//gi;
		$Text =~ s/<<\/?U>>//gi;
		$Text =~ s/<<T>>//gi;
		$Text =~ s/<<\/?TABLE>>//gi;
		$Text =~ s/<<VALUE\:\d+>>//gi;
		$Text =~ s/<<LIST_ID[^>]+>>//gi;
	}
	return ($Text);
}

############# SurveySetup:GetTextFormatting #############
#FUNCTION:   Provided a line of text looks through the text for formatting tags which affect the whole text line building a hash denoting all values
#PARAMATERS: Text
#RETURNS:	 Text hash denoting formatting
sub GetTextFormatting {
	my $Text = $_[0];	#TEXT BEING PROCESSED
	my @Formats;		#ARRAY USED TO TRACK FORMATS FOUND
	my $ReturnText="";	#TEXT RETURNED;
	my $NewFormat = 1;	#FLAG DENOTING THAT A NEW FORMAT HAS BEEN FOUND IN THE LATEST PASS THROUGH THE LOOP
	
	#CLEAR BLANK TAGS
	$Text =~ s/<<B>>\s*<<\/B>>//ig;
	$Text =~ s/<<I>>\s*<<\/I>>//ig;
	$Text =~ s/<<U>>\s*<<\/U>>//ig;
	
	$Text =~ s/<<T>>/ /gi;

	#REMOVE LIST DEF
	$Text =~ s/<<LIST_ID=[^>]+>>//;
	
	#LOOP UNTIL NO NEW FORMATS ARE FOUND, IF A FORMAT IS FOUND TEXT DENOTING SAID FORMAT IS REMOVED
	while($NewFormat){
		#CHECK IF THE ENTIRE LINE IS BOLDED
		if($Text =~ /^\s*<<B>>.*<<\/B>>\s*$/){
			$Formats[FORMAT_INDEX_BOLD] = 1;   
			$Text =~ s/^\s*<<B>>//;
			$Text =~ s/<<\/B>>\s*$//;
		}
		#CHECK IF THE ENTIRE LINE IS CAPITILIZED (NO LOWER CASE)
		elsif($Text !~ /[a-z]/ && $Text =~ /[A-Z]/ && (!(defined($Formats[FORMAT_INDEX_ALL_CAP])) || $Formats[FORMAT_INDEX_ALL_CAP] != 1)){
			$Formats[FORMAT_INDEX_ALL_CAP] = 1;   
		} 
		#TEXT IS WRAPPED BY SQUARE BRACKETS
		elsif($Text =~ /^\s*\[.*\]\s*$/){
			$Formats[FORMAT_INDEX_SQ_BRK] = 1;   
			$Text =~ s/^\s*\[//;
			$Text =~ s/\]\s*$//;			
		} 
		#TEXT IS WRAPPED BY CURLY BRACKETS
		elsif($Text =~ /^\{.*\}$/){
			$Formats[FORMAT_INDEX_CRLY_BRK] = 1;  
			$Text =~ s/^\s*\{//;
			$Text =~ s/\}\s*$//;	
		} 
		#CHECK IF THE ENTIRE LINE IS ITTALIC
		elsif($Text =~ /^\s*<<U>>.*<<\/U>>\s*$/){
			$Formats[FORMAT_INDEX_UNDERLINE] = 1;   
			$Text =~ s/^\s*<<U>>//;
			$Text =~ s/<<\/U>>\s*$//;
		}
		#CHECK IF THE ENTIRE LINE IS UNDERLINED
		elsif($Text =~ /^\s*<<I>>.*<<\/I>>\s*$/){
			$Formats[FORMAT_INDEX_ITTALIC] = 1;   
			$Text =~ s/^\s*<<I>>//;
			$Text =~ s/<<\/I>>\s*$//;
		}	
		else {
			$NewFormat=0;
		}
	}
	#ADD FORMATTING WEIGHTS
	for(my $Index = 0; $Index < scalar(@Formats); $Index++){
		#CHECK IF THIS FORMAT FLAG HAS BEEN SET
		if (defined ($Formats[$Index]) && $Formats[$Index]==1){
			$ReturnText .= '_' if($ReturnText ne "");
			$ReturnText .= $FormatHash[$Index]; 
		}
	}			
	return $ReturnText;	
}

############# SurveySetup:SegmentText #############
#FUNCTION:   Breaks functions into logical segments
#PARAMATERS: Text
#RETURNS:	 Array of segments
sub SegmentText{
	my $Text = $_[0];		#CURRENT TEXT
	my @Segments;			#ARRAY STORING SEGMENTS THE LIST ITEM IS COMPRIZED OF
	my $CapFlag = -1;		#DENOTES THAT THE CURRENT SEGMENT IS ALL CAPITALS (-1 - UNKNOWN, 0 - CAPITALIZED, 1 - MIXED)
	my $CurrentTag=0;		#STARTING TAG
	my $CurrentSegment='';  #CURRENT SEGMENT BEING BUILD
	
	#CONTINUE TO LOOP UNTIL TEXT IS EMPTY
	while ($Text =~ /\S/){	
		my $First = substr($Text,0,1);	#FIRST CHARACTER IN THE CURRENT STRING				
		#IF TEXT IS LED BY A TAG REPLACE WITH TAG
		$First = $1 if($Text =~ /^(<<[^>]+>>)/);
		#CHECK FOR LEADING SPACE		
		if ($Text =~ /^(\s+)/){
			$CurrentSegment .= $1;
			$Text =~ s /^(\s+)//i;		
		}
		#CHECK LEADING TEXT
		elsif (exists($Delimiters{$First})){
			my $TagID = $Delimiters{$First};	#ID OF THE CURRENT TAG			
			#CHECK FOR OPENING TAG
			if ($TagID < 10){
				#CHECK IF CURRENTLY IN BOUND TEXT SEGEMENT - WON'T BREAK ONE BOUND SEGMENT BY NESTED BOUND SEGMENT
				if($CurrentTag == 0){
					#ADD CURRENT SEGMENT TO LIST IF NOT BLANK			
					push (@Segments, $CurrentSegment) if($CurrentSegment ne '') ;  
					$CurrentTag=$TagID; 
					$CurrentSegment = '';	
					$CapFlag = -1;	
				}					
				$CurrentSegment .= $First;		
			}			
			#CHECK FOR CLOSING TAG
			elsif($TagID > 10 && $TagID <20) {
				#IF ENDING MATCHES CURRENT TAG
				$CurrentSegment .= $First;
				if($CurrentTag+10 == $TagID){
					#ADD CURRENT SEGMENT TO LIST IF NOT BLANK			
					push (@Segments, $CurrentSegment) if($CurrentSegment ne '') ; 
					#SET CURRENT TAG NOT TAB  
					$CurrentTag=0; 
					$CapFlag = -1;				
					$CurrentSegment = '';				
				}									 
			}
			#CHECK FOR TABS
			elsif($TagID == 20){
				#ADD CURRENT SEGMENT TO LIST IF NOT BLANK		
				$CurrentSegment .= $First;				
				push (@Segments, $CurrentSegment) if($CurrentSegment ne '') ;   
				#SET CURRENT TAG NOT TAB  
				$CurrentTag=0; 
				$CapFlag = -1;				
				$CurrentSegment = '';					
			}
			$Text =~ s/^\Q$First//i;		
		}
		#CHECK IF TEXT IS LED BY ALPHA NUMERIC
		elsif($Text =~ /^([a-z]+)/i){
			my $NewText = $1;		#LEADING TEXT FROM THIS LINE
			if (($CurrentTag == 0 && $CapFlag == 1 && $NewText =~/[a-z]/) || ($CurrentTag == 0 && $CapFlag==0 && length($NewText)>2 && $NewText !~/[a-z]/)){
				push (@Segments, $CurrentSegment) if($CurrentSegment ne '') ; 							
				$CurrentSegment = '';					
			}	
			#SET CAP FLAG
			if (length($NewText)>2 ){
				$CapFlag = $NewText =~ /[a-z]/ ? 0 : 1;			
			}
			$CurrentSegment .= $NewText;	
			$Text =~ s/^\Q$NewText//i;	
		}	
		#ANY OTHER CHARACTER;
		else {
			$CurrentSegment .= $First;		
			$Text =~ s/^\Q$First//	
		}		
	}				 
																																		
	#ADD LAST SEGMENT TO LIST	
	push (@Segments, $CurrentSegment) if($CurrentSegment ne '') ; 
	return (\@Segments);
}	

############# SurveySetup:SelectHigh #############
#FUNCTION:   Passed a hash where each key points to a number returns the key with the highest associated value
#PARAMATERS: Hash or Array, Debug Flag
#RETURNS:	 Key of Highest value, or Index of highest Value
sub SelectHigh{
	my $List = $_[0];			#HASH OF VALUES PROCESSED
	my $DebugFlag = $_[1];		#FLAG DENOTING TO PRINT PROCESS AND RESULTS
	$DebugFlag =0 if (! defined($DebugFlag));
	my $SelectedElement;		#KEY SELECTED
	#CHECK IF LIST IS REFERENCING A HASH
	if (ref($List) eq 'HASH'){
		#SELECT HIGHEST WEIGHT
		foreach my $Key (keys(%{$List})){
			print $Key." - ".$List->{$Key}."\n" if ($DebugFlag);;
			#IF NOTHING SELECTED SELECT
			$SelectedElement = $Key if (!(defined($SelectedElement)) || !(exists($List->{$SelectedElement})));
			#IF WEIGHT OF CURRENT ITEM IS GREATER THAN SELECTED ITM
			$SelectedElement = $Key if($List->{$Key} > $List->{$SelectedElement})
		}
		print $SelectedElement."\n" if ($DebugFlag);
		return $SelectedElement;
	}
	elsif(ref($List) eq 'ARRAY'){	
		#SELECT HIGHEST WEIGHT
		for(my $Index = 0; $Index < scalar(@{$List}); $Index++){
			print $Index." - ".$List->[$Index]."\n" if ($DebugFlag);;
			#IF NOTHING SELECTED SELECT
			$SelectedElement = $Index if (!(defined($SelectedElement)));
			#IF WEIGHT OF CURRENT ITEM IS GREATER THAN SELECTED ITM
			$SelectedElement = $Index if($List->[$Index] > $List->[$SelectedElement])
		}
		print $SelectedElement."\n" if ($DebugFlag);
		return $SelectedElement;
	}
	
	#DIE IF INVALID REFERNCE PROVIDED
	else{
		die 'Invalid reference povided."\n"';
	}
}


############# SurveySetup:GetWords #############
#FUNCTION:   Passed a line of text breaks text into word
#PARAMATERS: Hash or Array, Debug Flag
#RETURNS:	 Pointer to Array
sub GetWords{
	my $Text = $_[0];	#TEXT TO PROCESS

	$Text =~ s/([^A-Z0-9_])/ $1 /ig; #ADD SPACES BEFORE AND AFTER ANY NON-ALPHA NUMERIC CHARACTER	
	$Text =~ s/ +/ /g;              #REMOVE MULTIPLE SPACES

	my @TextList = split(" ",$Text);#BREAK TEXT INTO WORDS
	return \@TextList;
}

############# SurveySetup:KeywordID #############
#FUNCTION:   Provided a string and an array of keywords returns a 1 or 0 depending on if one of the keywords is found in the text
#PARAMATERS: Text, Array of Keywords
#RETURNS:	 1 or 0 depening on if a keyword has been found
sub KeywordID {
	my $Text = $_[0];				#TEXT TO LOOK UP IN
	my $Keywords = $_[1];			#HASH OF KEYWORDS POINTING TO WEIGHTS
	my $Found=0;					#RETURN FLAG
	
	#BREAK TEXT INTO WORDS
	my $TextList = GetWords($Text); 	
	#LOOP THROUGH KEYWORDS
	foreach my $Keyword (sort {length $b <=> length $a} (@$Keywords)){
		#LOOP THROUGH TEXT WORDS
		for (my $Index = 0; $Index < scalar(@$TextList); $Index++){
			#CHECK IF KEYWORD IS MULTIPLE WORDS			
			if($Keyword =~ / /){ 
				my $SpaceCount = () = ($Keyword =~ / /g); #NUMBER OF SPACES IN KEYWORKD
				my $MergedWords = "";					  #WORDS
				#LOOP MERGING WORDS
				for (my $WordIndex=0; $WordIndex<=$SpaceCount; $WordIndex++){
					$MergedWords .= $TextList->[$Index+$WordIndex]." " if (defined($TextList->[$Index+$WordIndex]));
				} 
				$MergedWords =~ s/ $//; #REMOVE TRAILING SPACE
				#CHECK IF KEYWORD IS THE SAME AS MERGED WORD
				if (uc($Keyword) eq uc($MergedWords)){
					$Found=1
				}				
			}
			#CHECK IF TEXT WORD EQUAL TO KEYWORD
			elsif(uc($TextList->[$Index]) eq uc($Keyword)){		
					$Found=1
			}
		}
	}
	return $Found;
} 

############# SurveySetup:GetPrevCode #############
#FUNCTION:   Provided a statement/choice code (alpha or numeric) and generates the code which preceeded this one
#PARAMATERS: Code (alpha or numeric)
#RETURNS:	 1 or 0 depening on if a keyword has been found
sub GetPrevCode {
	my $Code =	$_[0];	#CODE PROVIDED AS PARAMATER	
	
	#CHECK IF CODE IS NUMERIC
	if($Code =~ /\(?(\d+)\)?/){
		return $1 - 1;
	}	
	#IF CODE IS ALPHA
	else {
		return ConvertNumToID(ConvertIDToNum($Code)-1);
	}
}

############# SurveySetup:GetNextCode #############
#FUNCTION:   Provided a statement/choice code (alpha or numeric) and generates the code which follows this one
#PARAMATERS: Code (alpha or numeric)
#RETURNS:	 1 or 0 depening on if a keyword has been found
sub GetNextCode {
	my $Code =	$_[0];	#CODE PROVIDED AS PARAMATER	
	#CHECK IF CODE IS NUMERIC
	if($Code =~ /\(?(\d+)\)?/){

		return $1 + 1;
	}	
	#IF CODE IS ALPHA
	else {
		return ConvertNumToID(ConvertIDToNum($Code)+1);
	}
}


############# SurveySetup:Keyword Search #############
#FUNCTION:   Provided a string and an hash of keywords pointing to weights this script sums all keywords found and returns this value, 
# three referenced variables are also updated denoting that the text consisted of only positive keywords, only negative keywords or any keyword. 
# The program assumes these flags are true (1) on execution and updates them to false (0) if determine that they are not true.
#PARAMATERS: Text, Keyword Hash, Only Positive Reference, Only Negative Reference, Only Keywords reference
#RETURNS:	 Sum of weights of Keywords found
sub KeywordSearch{
	my $Text = $_[0];				#TEXT TO LOOK UP IN
	my $Keywords = $_[1];			#HASH OF KEYWORDS POINTING TO WEIGHTS
	my $AllPositiveUsed = $_[2];	#REFERENCE TO FLAG DENOTING THAT THE TEXT IS ALL POSITIVE KEYWORDS
	my $AllNegativeUsed = $_[3];    #REFERENCE TO FLAG DENOTING THAT THE TEXT IS ALL NEGATIVE KEYWORDS 
    my $AllUsed = $_[4];            #REFERENCE TO FLAG DENOTING THAT THE TEXT IS ALL KEYWORDS
	my $KeywordCount = $_[5];		#REFERENCE TO FLAG COUNTING THE NUMBER OF KEYWORDS IN THE FILE
	my $Weight=0;					#SUMMED WEIGHT OF ALL KEYWORDS
		
	#BREAK TEXT INTO WORDS
	my $TextList = GetWords($Text); 
	#print Dumper $TextList;
	$$KeywordCount=0;		#CLEAR KEYWORD COUNT
	#LOOP THROUGH KEYWORDS
	foreach my $Keyword (sort {length $b <=> length $a} keys(%$Keywords)){
		#LOOP THROUGH TEXT WORDS
		for (my $Index = 0; $Index < scalar(@$TextList); $Index++){	
			#CHECK IF KEYWORD IS MULTIPLE WORDS				
			if($Keyword =~ / /){ 
				my $SpaceCount = () = ($Keyword =~ / /g); #NUMBER OF SPACES IN KEYWORKD
				my $MergedWords = "";					  #WORDS
				#LOOP MERGING WORDS
				for (my $WordIndex=0; $WordIndex<=$SpaceCount; $WordIndex++){
					$MergedWords .= $TextList->[$Index+$WordIndex]." " if (defined($TextList->[$Index+$WordIndex]));
				} 
				$MergedWords =~ s/ $//; #REMOVE TRAILING SPACE
				#CHECK IF KEYWORD IS THE SAME AS MERGED WORD				
				if (uc($Keyword) eq uc($MergedWords)){
					$Weight+=$Keywords->{$Keyword};
					#LOOP THROUGH WORDS
					for (my $WordIndex=0; $WordIndex<=$SpaceCount; $WordIndex++){
						$TextList->[$Index+$WordIndex]="";
					}
					#UPDATE FLAGS
					$$AllPositiveUsed=0 if($Keywords->{$Keyword}<0);
					$$AllNegativeUsed=0 if($Keywords->{$Keyword}>0);	
					$$KeywordCount++;
				}				
			}
			#CHECK IF TEXT WORD EQUAL TO KEYWORD
			elsif(uc($TextList->[$Index]) eq uc($Keyword)){					
				$Weight+=$Keywords->{$Keyword};
				$TextList->[$Index]="";
				#UPDATE FLAGS
				$$AllPositiveUsed=0 if($Keywords->{$Keyword}<0);
				$$AllNegativeUsed=0 if($Keywords->{$Keyword}>0);	
				$$KeywordCount++;
			}
		}
	}
	my $RemainingText = join(" ",@$TextList);
	$$AllUsed=0 if($RemainingText =~ /[a-z]/ig || $$KeywordCount==0);
	$$AllPositiveUsed=0 if($RemainingText =~ /[a-z]/ig || $$KeywordCount==0);
	$$AllNegativeUsed=0 if($RemainingText =~ /[a-z]/ig || $$KeywordCount==0);
	return $Weight;
}
	
	
############# SurveySetup:GetNumbers #############
#FUNCTION:   Provided a line of text finds each unique number in the text and returns a sorted list
#PARAMATERS: Text
#RETURNS:	 Sorted list of numbers
sub GetNumbers{
	my $Text = $_[0];				#TEXT TO LOOK UP IN
	my %TrackUnique;				#HASH USED TO TRACK UNIQUE VALUES
	my @ReturnList;					#ARRAY RETURNED FROM THIS FUNCTION
	while ($Text =~ /[^a-z](\d+)[^a-z]/gi) {
		if(!(exists($TrackUnique{$1}))){
			push(@ReturnList,$1);
			$TrackUnique{$1}=1;
			
		}
	}
	return(\@ReturnList);
}


############# SurveySetup:RunReformatting #############
#FUNCTION:   Provided a Config Structure and a text returns reformatted text
#PARAMATERS: Text, Config
#RETURNS:	 Reforamtted Text
sub RunReformat{
	my $Text = $_[0];		#TEXT TO REFORMAT
	my $Config = $_[1];		#CONFIG CONTROLLING REFORMAT
	
	my $Found=1;
	my $First=1;	
	return $Text if (!defined($Text));
	while($Found){
		$Found=0;
		#CLEAN UP TEXT AROUND FORMATTING
		foreach my $CleanupText (@$Config){			
			if($First == 1 || exists($CleanupText->{CYCLIC})){
				my $ToReplace = $CleanupText->{SEARCH};		
				my $LeadReplace = '^'.$ToReplace;	#TEXT TO CHECK LEADING
				my $TrailReplace = $ToReplace.'$'; #TEXT TO CHECK TRAILING
				#print "HERE  - ". $ToReplace ."\n" if ($Text=~ /^$ToReplace/gi && exists($CleanupText->{LEADING})); 
				my $Pass =0;  #PASS FOUND
				if(exists($CleanupText->{LEADING})){
					if ($Text=~ /^$ToReplace/gi){$Pass=1 ;}
				}
				elsif( exists($CleanupText->{TRAILING})){
					if ($Text=~ /$ToReplace$/gi){$Pass=1;}
				}
				else {			
					if ($Text=~ /$ToReplace/gi){$Pass=1;}										
				}
				if ($Pass){
					#REPLACE WITH FIRST FOUND SUBSTRING
					if (exists($CleanupText->{REPLACE_FIRST})){
						$Text=~ s/$ToReplace/$1/gi;
						$Found=1;
					}
					elsif (exists($CleanupText->{CLEAR})){
						if(exists($CleanupText->{LEADING})){$Text=~ s/^$ToReplace//gi;}
						elsif(exists($CleanupText->{TRAILING})){$Text=~ s/$ToReplace$//gi;}
						else{$Text=~ s/$ToReplace//gi;}
						$Found=1;
					}
					elsif(exists($CleanupText->{REPLACE})){
						my $ReplaceWith = $CleanupText->{REPLACE};
						$Text=~ s/$ToReplace/$ReplaceWith/gi;
						$Found=1;
					}
					elsif(exists($CleanupText->{REPLACE_SPACE})){
						$Text=~ s/$ToReplace/ /gi;
						$Found=1;
					}
					elsif(exists($CleanupText->{PRE_SPACE})){
						$Text=~ s/$ToReplace/ $1/gi;
						$Found=1;
					}		
					elsif(exists($CleanupText->{POST_SPACE})){
						$Text=~ s/$ToReplace/$1 /gi;
						$Found=1;
					}	
				}
			}
		}
		$First=0;	
	}	
	return($Text);
}

	
1;