#!perl


########################################################################################################
############################################## BUILD STRUCTURE #########################################
########################################################################################################
#DESCRIPTION: CONTROL CLASS USED TO MERGE PROVIDED JOSN FILE AND MAP INTO PRE-0DEFIEND SECTION BLOCS
#TODO:
#CHANGE LOG:
package BuildSection;
	
use warnings;
use strict;
use Data::Dumper;

########################################################################################################
############################################## CONSTRUCTOR #############################################
########################################################################################################
############# SurveyStruct:New #############
#FUNCTION:   Object Constructor - Builds a SurveySetupLogic object, breaks down provided text into tree(s) and generates flags
#PARAMATERS: Structure JSON File, Content JSON File.
#RETURNS:	 Nothing
sub New {
    my $Class = shift();		#CLASS
	my %DataLookup;				#STRUCTURE CONTAINIGN ALL LOOKUP ITEMS
    my $Self = {
		SECTION => shift(),		#JSON FILE PROVIDE WHICH DEFINES POSSIBLE STRUCTURAL SURVEY LAYOUT
		STRUCTURE => shift(),	#JSON FILE PROVIDE WHICH DEFINES POSSIBLE STRUCTURAL SURVEY LAYOUT
		CONTENT => shift(),		#JSON FILE PROVIDED
		DATA_LOOKUP => \%DataLookup,
    };	
	bless $Self, $Class;
	#MERGE STRUCTURE AND CONTENT TO CREATE UNIVERAL DATAMAP
	foreach my $Key (keys(%{$Self->{SECTION}})){
		$Self->{DATA_LOOKUP}->{$Key} = $Self->{SECTION}->{$Key};
	}
	
	foreach my $Key (keys(%{$Self->{CONTENT}})){
		if(! exists($Self->{DATA_LOOKUP}->{$Key})){
			$Self->{DATA_LOOKUP}->{$Key} = $Self->{CONTENT}->{$Key};	
		}
		else{
			die("ERROR - DUPLICATE KEY FOUND IN STRUCTURE AND CONTENT FILES\n");
		}
	}
	
    return $Self;
}


########################################################################################################
########################################### EXTERNAL ELEMENTS ##########################################
########################################################################################################
############# SurveyStruct:New #############
#FUNCTION:   Provided a reference processes it and return sn associated values
#PARAMATERS: Reference
#RETURNS:	 Value
sub GetIdentifierValue{
	my $Self = $_[0];
	my $Reference = $_[1];
	my $Index = $_[2];
	
	#ADD GLOBAL LOOKUP HERE
	if(exists($Self->{STRUCTURE}->{"VALUESLOOKUP"}->{$Reference})){
		if(exists($Self->{STRUCTURE}->{"VALUESLOOKUP"}->{$Reference}->{"INCREMENTONUSE"})){
			$Self->{STRUCTURE}->{"VALUESLOOKUP"}->{$Reference}->{"VALUE"}+=1;
		}
		if(exists($Self->{STRUCTURE}->{"VALUESLOOKUP"}->{$Reference}->{"INCREMENT"})){
			$Self->{STRUCTURE}->{"VALUESLOOKUP"}->{$Reference}->{"TOUPDATE"}=1;
		}
		return ($Self->{STRUCTURE}->{"VALUESLOOKUP"}->{$Reference}->{"VALUE"});
	}

	#CHECK IF ID CONTIANS _ (DENOTES SUB SECTION)
	my @References = split('_', $Reference);	#REFERENCES DIVIED FROM _ REFERENCE
	my $CurrentRef=$Self->{DATA_LOOKUP};			#CURRENT LOOKUP STRUCTURE
	#LOOK THROUGH REFERENCE TEXT
	foreach my $RefText (@References){			
		#CHECK FOR IF DEFIEN DVALUE EXISTS (CAN OVERRIDE BELOW
		if(ref($CurrentRef) eq "HASH" && exists($CurrentRef->{$RefText})){
			$CurrentRef=$CurrentRef->{$RefText};
		}
		#LOOK FOR NEXT HASH REFERENCE
		elsif(uc($RefText) eq "INDEX"){
			$CurrentRef = $Index+1;
		}
		#CHECK FOR INDEX VARIABLE (DENOTES INDEX IN PROVIDE LIST)
		elsif(uc($RefText) eq "INDEXID"){
			$CurrentRef = chr($Index + ord ('A'));
		}		
		else{
				return ("");
			#die("ERROR: Unidentified Reference ".$RefText." encoutnered.\n");	
		}
		#CHECK IF CURRENT REFFERENCE IS AN ARRAY 
		if(ref($CurrentRef) eq "ARRAY"){
			#CHECKS IF AN INDEX IS PROVIDED
			if($Index =~ /\d/ && $Index >= 0){
				$CurrentRef=$CurrentRef->[$Index];
			}
		}			
	}
	return ($CurrentRef);
	
#	print $Reference."\n";
#	print Dumper $Self;
#	
#	die;

}

1;