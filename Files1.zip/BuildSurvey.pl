#!perl


use warnings;
use strict;
use Data::Dumper;
use Try::Tiny;
use utf8;
use open IO => ':utf8';
use JSON;
use MIME::Base64;
use REST::Client;

use Development::BuildSurvey::SurveyStruct;
use Development::BuildSurvey::CheckJSON;


########################################################################################################
############################################# BUILD SURVEY #############################################
########################################################################################################
#DESCRIPTION: Provided a base structure JSON configuration file, along with a specific JSON content file this program merges field provided in both alogn with pre-designated template files to build a survey text file
#PARAMATERS: Structure File, Content File, Output File

########################################################################################################
########################################## CONSTANDS AND GLOBALS #######################################
########################################################################################################
my $Host = 'https://logit.decipherinc.com/';									  #MAIN HOST FOR ULOAD
my $APIKey =  'wbgxmsbbep9dp93t8kb12kbde7x625g995wwgk6vhd0d6uv1ntpdb4mfnvj1umtm'; #API KEY FOR UPLOAD

my $Structure;		#PARESED QUESTIONAIRE STRUCUTRE DATA STRUCTURE
my $Content ;		#PARESED CONTENT DATA STRUCTURE

########################################################################################################
########################################## SECONDARY FUNCTIONS #########################################
########################################################################################################
############# Parse JSON #############
#FUNCTION:   Provided a JSON file parses it into it's defined structure 
#PARAMATERS: JSON File
#RETURNS:	 JSON Structure
sub ParseJSON{
	my $JSONFile = $_[0];			#FILE NAME TO PROCESS
	
	#VERIFY JSON FILE SYNTAXT
	try{
		my $CheckJSONObject = New CheckJSON($JSONFile);
	}
	catch{
		die($_);		
	};
	
	my $FileText = do {
	   open(my $JSONFileHandle, "<:encoding(UTF-8)", $JSONFile) or die("Can't open \"$JSONFile\": $!\n");
	   local $/;
	   <$JSONFileHandle>
	};

	my $JSON = JSON->new;
	my $Structure = $JSON->decode($FileText);	
	
	return $Structure;
}

########################################################################################################
########################################## MAIN FUNCTION  ##############################################
########################################################################################################

#my $StructureFileName = "Templates/Hotspex_Control.json";
#my $ContentFileName =  "Test_Content.json";

#CHECK FOR VALID PARAMATERS
if (scalar(@ARGV) <3){
	print "USAGE: BuildSurvey.pl Strucutre File, Content File, Output File";		
	exit();
}

my $StructureFileName = shift(@ARGV);
my $ContentFileName = shift(@ARGV);
my $OutputFile = shift(@ARGV);

$Structure= ParseJSON($StructureFileName);
	$Content = ParseJSON($ContentFileName);
	
	
		my $SurveyStructure = New SurveyStruct($Structure,$Content);
	$SurveyStructure->BuildSurvey($OutputFile);


#CHECK IF JSON CONTAINS PATH - UPLOAD IF PRESENT
if (exists($Content->{"PATH"}) && $Content->{"PATH"}=~ /[a-z0-9]/i){
	my $Path = $Content->{"PATH"};  #SURVEY PATH
	
	#CLEAN LEADING PATH inf
	$Path =~ s/^\/?api//;
	$Path =~ s/^\/?v1//;
	$Path =~ s/^\/?surveys//;
	$Path =~ s/^\/?selfserve//;
	$Path =~ s/^\/?53b//;
	$Path =~ s/^\///;
	
	#CLEAN TRAILING - ANYTHIGN AFTER A /
	$Path =~ s/\/.*$//;
	
	#INITIALIZE API OBJECT
	my $Client = REST::Client->new();
	$Client->setHost($Host);
	$Client->addHeader('x-apikey', $APIKey );
	
	#BUILD UPLOAD DATA STRUCTURE JSON
	my $SurveyText = do {		#TEXT FROM THE SURVEY
		local $/ = undef;
		open my $FileHandle, "<", $OutputFile or die "could not open $OutputFile: $!";
		<$FileHandle>;
	};

	my $UploadJSON = encode_json {  #JSON DATA STRCUTRE
	contents => $SurveyText, 
	validate  => "false",  
	overwriteLive  => "false",  
	location  => "root"
	}; 

	$Client->PUT('/api/v1/surveys/selfserve/53b/'.$Path.'/files/survey.xml', $UploadJSON,{"Content-Type"=>"application/json"});

}




