#!perl

########################################################################################################
############################################## SURVEY STRUCT ###########################################
########################################################################################################
#DESCRIPTION: CONTROL CLASS USED TO MERGE PROVIDED JOSN FILE AND MAP INTO PRE-0DEFIEND SECTION BLOCS
#TODO:
#CHANGE LOG:
package SurveyStruct;

use warnings;
use strict;
use Data::Dumper;
use JSON;
use Development::BuildSurvey::BuildSection;
use Development::BuildSurvey::QuestionaireMisc;
use Development::BuildSurvey::QuestionaireExportTemplate;




########################################################################################################
###################################### MAIN INTERNAL FUNCTIONS #########################################
########################################################################################################
############# SurveyStruct:Build Structure Lookup #############
#FUNCTION:   Builds lookup tables from provided arrays for future use
#PARAMATERS: Nothing
#RETURNS:	 Nothing
sub __BuildStructureLookup {
	my $Self = $_[0];	
	my %ValueLookup; #NEW STRUCUTRE TO LOOK VALUES BASE ON NAME
	if(exists($Self->{STRUCTURE}->{"VALUES"})){
		foreach my $Value (@{$Self->{STRUCTURE}->{"VALUES"}}){
			$ValueLookup{$Value->{"NAME"}} = $Value;
		}
	}
	$Self->{STRUCTURE}->{"VALUESLOOKUP"}= \%ValueLookup;
}

############# SurveyStruct:Map Content #############
#FUNCTION:   Using mapping values provided in the STRUCTURE data strucutre updates the content data strcuture
#PARAMATERS: Nothing
#RETURNS:	 Nothing
sub __MapContent{
	my $Self = $_[0];
	if(exists($Self->{STRUCTURE}->{"MAPING"})){
		my $Mapping = $Self->{STRUCTURE}->{"MAPING"}; #MAPPING STRUCTURE
		#CHECK FOR TERM MAPPING
		if(exists($Mapping->{"TERMS"})){
			#LOOP THROUGH MAPING	
			foreach my $Term (keys(%{$Mapping->{"TERMS"}})){
				#CHECK IF TERM EXISTS IN CONTENT			
				if(exists($Self->{CONTENT}->{$Term})){
					$Self->{CONTENT}->{$Mapping->{"TERMS"}->{$Term}} = $Self->{CONTENT}->{$Term};
				}
			}
		}
		#CHECK FOR DATA MAPPING
		if(exists($Mapping->{"VALUES"})){
			#LOOP THROUGH MAPING
			foreach my $Term (keys(%{$Mapping->{"VALUES"}})){
				#CHECK IF TERM EXISTS IN CONTENT
				if(exists($Self->{CONTENT}->{$Term})){
					#CHECK IF MAPPING CONTAINS PROVIDED VALUE AND REPLACE IF IT DOES
					if(exists($Mapping->{"VALUES"}->{$Term}->{$Self->{CONTENT}->{$Term}})){
						$Self->{CONTENT}->{$Term} = $Mapping->{"VALUES"}->{$Term}->{$Self->{CONTENT}->{$Term}};						
					}
				}			
			}
		}
	}
	
	#TODO - MIGHT WANT TO LOOK AT ERROR IF MISSING SPECIFIC MAPPING - OR LET FALL THROUGH NOT SURE WHICH WAY TO GO
	#MAYBE A SECONDARY VERIFICATION CHECK AFTER MAPPING. 
}


############# SurveyStruct:ProcessSection #############
#FUNCTION:   
#PARAMATERS: Nothing
#RETURNS:	 Nothing
sub __ProcessSection{
	my $Self= $_[0];
	my $Section = $_[1]; #SECTION TO PROCESS
	
	my $SectionStructure = New BuildSection($Section, $Self->{STRUCTURE}, $Self->{CONTENT});
	my $Exporter = New QuestionaireExportTemplate($Self->{DIRECTORY}.$Section->{"FILE"});	#EXPORTER OBJECT
	return($Exporter->Export($SectionStructure));
	

}

########################################################################################################
############################################## CONSTRUCTOR #############################################
########################################################################################################
############# SurveyStruct:New #############
#FUNCTION:   Object Constructor - Builds a SurveySetupLogic object, breaks down provided text into tree(s) and generates flags
#PARAMATERS: Structure JSON File, Content JSON File.
#RETURNS:	 Nothing
sub New {
    my $Class = shift();		#CLASS
    my $Self = {		
		STRUCTURE => shift(),	#JSON FILE PROVIDE WHICH DEFINES POSSIBLE STRUCTURAL SURVEY LAYOUT
		CONTENT => shift(),		#JSON FILE PROVIDED
		
    };	
	bless $Self, $Class;
	#READ FILE
	local $/;
	
	$Self->__BuildStructureLookup();
	$Self->{DIRECTORY} =  $Self->{STRUCTURE}->{"DIRECTORY"};	
	
	#REDEFINE DATA ACCORDING TO PROVIDIGN MAPPING
	$Self->__MapContent();

#	print Dumper  $Self->{STRUCTURE} ;	
#	print Dumper  $Self->{CONTENT} ;	
	
    return $Self;
}

########################################################################################################
######################################### EXTERNAL FUNCTIONS ###########################################
########################################################################################################

############# SurveyStruct:BuildSurvey #############
#FUNCTION:   Object Constructor - Builds a SurveySetupLogic object, breaks down provided text into tree(s) and generates flags
#PARAMATERS: Structure JSON File, Content JSON File.
#RETURNS:	 Nothing
sub BuildSurvey {
	my $Self = $_[0];	
	my $OutputFile = $_[1];		#FILE NAME OF THE OUTPUT FILE 
	my $ReturnText = "";		#TEXT TO RETURN
	#LOOP THROUGH SECTIONS
	foreach my $Section (@{$Self->{STRUCTURE}->{"SECTIONMAP"}}){
		my $PassFail = 1;	#BOOL TRACK PASS REQ CHECK.
		#CHECK PREREQUISITES
		if(exists($Section->{"REQUIREMENTS"})){
			#LOOP THROUGH EACH REQUIREMENT
			foreach my $ReqKey (keys(%{$Section->{"REQUIREMENTS"}})){
				my $ContentValue; #THE VALUE ASSOCIATED WITH THE CONTENT
				#POPULATE CURRENT VALUE
				$ContentValue=$Self->{CONTENT}->{$ReqKey};
				#TEST IF LIST OF VALUES GIVEN
				if(ref($Section->{"REQUIREMENTS"}->{$ReqKey}) eq "ARRAY"){
					my $Found = 0; #BOOL TRACKING PASS IN ARRAY
					foreach my $ValidValue (@{$Section->{"REQUIREMENTS"}->{$ReqKey}}){
						if($ValidValue eq $ContentValue){
							$Found = 1;
							last();
						}						
					}
					$PassFail = $PassFail && $Found;
					
				}
				#SINGLE VALUE
				else{
					if($Section->{"REQUIREMENTS"}->{$ReqKey} ne $ContentValue){
						$PassFail = 0;				
					}			
				}				
			}
		}
		#IF NO REQUIREMENT OR ALL PASSED, TRIGGER PROCESSING APPEND TO OUTPUT
		if($PassFail){
			$ReturnText .= $Self->__ProcessSection($Section);
			#UPDATE INCREMENT FLAGS IN VALEU STRUCTURE
			if(exists($Self->{STRUCTURE}->{"VALUES"})){
				#LOOP THROUGH THE VALUES AND INCREAMENT IF NEEDED
				foreach my $Value (@{$Self->{STRUCTURE}->{"VALUES"}}){
					if(exists($Value->{"INCREMENT"}) && exists($Value->{"TOUPDATE"}) && $Value->{"TOUPDATE"} == 1){
						$Value->{"VALUE"} +=1;
						$Value->{"TOUPDATE"} = 0;
					}					
				}				
			}
		}	
	}
	open(OUTPUT_FILE, ">". $OutputFile) or die("Can't open \"$OutputFile\": $!\n");
	print OUTPUT_FILE $ReturnText;
	close(OUTPUT_FILE);
}

1;

