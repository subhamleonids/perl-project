#!perl


########################### CHECK JSON ###########################


########################################################################################################
############################################ PROCESS CONFIG ############################################
########################################################################################################
#DESCRIPTION: Breaks up a json file and checks for consistancy
#GENERAL USAGE
#TODO:
#CHANGE LOG:

package CheckJSON;

use warnings;
use strict;
use Data::Dumper;
use Try::Tiny;
use Text::Iconv;


########################################################################################################
################################## PROTOTYPES VARIABLES AND CONSTANTS ##################################
########################################################################################################
sub CheckPass__($$);
sub Parse__($);
sub ParseList__($);
sub ParseHash__($);

########################################## CONSTANTS ##########################################
#LEX CONSTANTS
use constant TOKEN_TYPE  	=> 0;
use constant TOKEN_VALUE 	=> 1;
use constant TOKEN_LINE_NUM => 2;

#NODE CONSTANTS
use constant NODE_TYPE  => 0;
use constant NODE_VALUE => 1;
use constant NODE_LCHILD => 2;
use constant NODE_RCHILD => 3;


############# CONFIG PROCESSING #############
#TOKEN TYPES
use constant TOKEN_TYPE_COLON		  		=> 0;
use constant TOKEN_TYPE_COMMA		  		=> 1;
use constant TOKEN_TYPE_OPEN_SQ_BRACKET  	=> 2;
use constant TOKEN_TYPE_CLOSE_SQ_BRACKET  	=> 3;
use constant TOKEN_TYPE_OPEN_CR_BRACKET  	=> 4;
use constant TOKEN_TYPE_CLOSE_CR_BRACKET  	=> 5;
use constant TOKEN_TYPE_STRING		  		=> 6;
use constant TOKEN_TYPE_NUMBER		  		=> 7;
use constant TOKEN_TYPE_BOOLEAN		 		=> 8;



########################################## LOOK UP HASH ##########################################
my %TokenCharacter = (					#Key characters found in config
	':'   => 0,
	','   => 1,
	'['   => 2,
	']'   => 3,
	'{'   => 4,
	'}'   => 5,	
);

my %CharacterLookup = (					#LOOKUP TO RETURN CHARACTER
	0 => ':',
	1 => ',',
	2 => '[',
	3 => ']',
	4 => '{',
	5 => '}',	
	6 => "String",
	7 => "Number",
	8 => "Boolean"	
);


########################################################################################################
########################################## MINOR FUNCTIONS ##########################################
########################################################################################################	
############# CHECK PASS #############
#FUNCTION: Checks the token list against the provided value removing it if true
#PARAMATERS: TokenList,Value,OptionalFlag
#RETURNS:	 Boolean
sub CheckPass__($$){
	my $TokenList=$_[0];	#TOKEN LIST
	my $CheckValue=$_[1];	#TOKEN TYPE TO MATCH		
	if(!defined ($TokenList->[0])){
		die "Error: Unexpected end of file encountered, expected:". $CharacterLookup{$CheckValue}."\n";
	}	
	if(scalar(@$TokenList)>0){
		if($TokenList->[0]->[TOKEN_TYPE] == $CheckValue){
			shift(@$TokenList);
			return 1;
		}
	}	
	die "Error: Line: ".$TokenList->[0]->[TOKEN_LINE_NUM]." Unexpected Token Ecountered expected:".  $CharacterLookup{$CheckValue}." found: ".$CharacterLookup{$TokenList->[0]->[TOKEN_TYPE]}."\n";
	return 0;
}

########################################################################################################
########################################## INTERNAL FUNCTIONS ##########################################
########################################################################################################

########################################### PARSING FUNCTIONS ##########################################
############# LEX FILE #############
#FUNCTION: Reduces provided text to a list of tokens used for further processing
#PARAMATERS: Text
#RETURNS:	Series of Tokens
sub LexConfig__($){
	my $Text = $_[0];		#TEXT TO BE PROCESSED	
	my @Tokens;					#ARRAY USED TO STORE TOKENS	
	my $LineNumber=1;			#TRACKING FOR LINE NUMBER
	#LOOP WHILE CONFIG TEXT	
	while($Text =~/\S/){		
		my @NewToken;						 #LIST OF TOKENS GENERATED FROM THIS PROCESS		
		#STRIP LEADING SPACE
		$Text =~ s/^\s+//;
		my $FirstChar = substr($Text, 0, 1);  #CURRENT FIRST CHARACTER IN THE STRING;
		
		#CHECK FOR LINE NUMBER DEFINITION
		if($Text =~ /^\$\#\$(\d+)\$\#\$/){
			$LineNumber=$1;
			$Text =~ s/^\$\#\$(\d+)\$\#\$//;
		}		
		#CHECK FOR RESERVED CHARACTER CREATE TOKEN IF DETECTED
		elsif (exists ($TokenCharacter{$FirstChar})){
			$NewToken[TOKEN_TYPE]=$TokenCharacter{$FirstChar};
			$NewToken[TOKEN_VALUE]=$FirstChar;
			$NewToken[TOKEN_LINE_NUM]=$LineNumber;
			$Text = substr ($Text, 1);
			push(@Tokens,\@NewToken);
		}	
		#ELSE EITHER FUNCTION CALL OR IDENTITY ELEMENT
		else{	
			#CHECK FOR BOOLEAN (KEYWORD(
			if($Text =~ /^(false|true)/){
				$NewToken[TOKEN_TYPE]=TOKEN_TYPE_BOOLEAN;
				$NewToken[TOKEN_VALUE]=$1;
				$NewToken[TOKEN_LINE_NUM]=$LineNumber;
				$Text =~ s/^(false|true)//;
				push(@Tokens,\@NewToken);
			}
			#CHECK FOR STRING - PATTERN MATCH ALLOWS FOR ESCAPED " 
			elsif($Text =~ /^(\"((\\\")?([^"]*\\\")*([^"]*[^\\"]+)(\\\")?)?\")/){
				$NewToken[TOKEN_TYPE]=TOKEN_TYPE_STRING;
				$NewToken[TOKEN_VALUE]=$1;
				$NewToken[TOKEN_LINE_NUM]=$LineNumber;		
				$Text =~ s/^(\"((\\\")?([^"]*\\\")*([^"]*[^\\"]+)(\\\")?)?\")//;
				push(@Tokens,\@NewToken);
			}
			#CHECK FOR NUMBER
			elsif($Text =~ /^(-?(?=[1-9]|0(?!\d))\d+(\.\d+)?([eE][+-]?\d+)?)/){
				$NewToken[TOKEN_TYPE]=TOKEN_TYPE_NUMBER;
				$NewToken[TOKEN_VALUE]=$1;
				$NewToken[TOKEN_LINE_NUM]=$LineNumber;	
				$Text =~ s/^(-?(?=[1-9]|0(?!\d))\d+(\.\d+)?([eE][+-]?\d+)?)//;
				push(@Tokens,\@NewToken);
			}		
			#OTHEWISE DIE WITH ERROR
			else{			
				$Text =~ s/\$\#\$.*//;
				$Text =~ s/\n//g;
				die( "ERROR: Line: $LineNumber Unidentified Token encoutnered at: $Text \n ");
			}
		}
	}
	return (\@Tokens);
}

############# PARSE #############
#FUNCTION: Progresses through provided toke list lookign for errrors
#PARAMATERS: TokenList
#RETURNS:	Data Structure
sub Parse__($){
	my $Tokens = $_[0];	#LIST OF TOKENS PROCESSED
	#CHECK IF BASE STRUCTURE IS A LIST
	if($Tokens->[0]->[TOKEN_TYPE]==TOKEN_TYPE_OPEN_SQ_BRACKET){
		ParseList__($Tokens)		
	}
	#CHECK IF BASE STRUCTURE IS A LIST
	elsif($Tokens->[0]->[TOKEN_TYPE]==TOKEN_TYPE_OPEN_CR_BRACKET){
		ParseHash__($Tokens)
	}
}
############# PARSE LIST #############
#FUNCTION: Progresses through provided toke list lookign for errrors
#PARAMATERS: TokenList
#RETURNS:	Nothing
sub ParseList__($){
	my $Tokens = $_[0];	#LIST OF TOKENS PROCESSED
	CheckPass__($Tokens,TOKEN_TYPE_OPEN_SQ_BRACKET);
	#LOOP UNTIL BREAK
	while(1){
		#CHECK IF BASE STRUCTURE IS A LIST
		if($Tokens->[0]->[TOKEN_TYPE]==TOKEN_TYPE_OPEN_SQ_BRACKET){
			ParseList__($Tokens)		
		}
		#CHECK IF BASE STRUCTURE IS A LIST
		elsif($Tokens->[0]->[TOKEN_TYPE]==TOKEN_TYPE_OPEN_CR_BRACKET){
			ParseHash__($Tokens)
		}
		elsif($Tokens->[0]->[TOKEN_TYPE]==TOKEN_TYPE_STRING || $Tokens->[0]->[TOKEN_TYPE]==TOKEN_TYPE_NUMBER || $Tokens->[0]->[TOKEN_TYPE]==TOKEN_TYPE_BOOLEAN){
			shift(@$Tokens);		
		}
		else {
			die "Error: Line: ".$Tokens->[0]->[TOKEN_LINE_NUM]." Expected Value, Array or Object Found:" .$Tokens->[0]->[TOKEN_TYPE]."\n";			
		}
		#CHECK IF A COMMAN - IF SO REMOVE COMMAND AN CONTINUE
		if($Tokens->[0]->[TOKEN_TYPE]==TOKEN_TYPE_COMMA){
			shift(@$Tokens);
		}
		#otherwise break from list
		else{
			last();			
		}
					
	}
	CheckPass__($Tokens,TOKEN_TYPE_CLOSE_SQ_BRACKET);
}
############# PARSE LIST #############
#FUNCTION: Progresses through provided toke list lookign for errrors
#PARAMATERS: TokenList
#RETURNS:	Nothing
sub ParseHash__($){
	my $Tokens = $_[0];	#LIST OF TOKENS PROCESSED
	CheckPass__($Tokens,TOKEN_TYPE_OPEN_CR_BRACKET);
	#LOOP UNTIL BREAK
	while(1){
		CheckPass__($Tokens,TOKEN_TYPE_STRING);
		CheckPass__($Tokens,TOKEN_TYPE_COLON);
		#CHECK IF BASE STRUCTURE IS A LIST
		if($Tokens->[0]->[TOKEN_TYPE]==TOKEN_TYPE_OPEN_SQ_BRACKET){
			ParseList__($Tokens)		
		}
		#CHECK IF BASE STRUCTURE IS A LIST
		elsif($Tokens->[0]->[TOKEN_TYPE]==TOKEN_TYPE_OPEN_CR_BRACKET){
			ParseHash__($Tokens)
		}
		elsif($Tokens->[0]->[TOKEN_TYPE]==TOKEN_TYPE_STRING || $Tokens->[0]->[TOKEN_TYPE]==TOKEN_TYPE_NUMBER || $Tokens->[0]->[TOKEN_TYPE]==TOKEN_TYPE_BOOLEAN){
			shift(@$Tokens);		
		}
		else {
			die "Error: Line: ".$Tokens->[0]->[TOKEN_LINE_NUM]." Expected Value, Array or Object Found:" .$Tokens->[0]->[TOKEN_TYPE]."\n";			
		}
		#CHECK IF A COMMAN - IF SO REMOVE COMMAND AN CONTINUE
		if(defined($Tokens->[0]) && $Tokens->[0]->[TOKEN_TYPE]==TOKEN_TYPE_COMMA){
			shift(@$Tokens);
		}
		#otherwise break from list
		else{
			last();			
		}					
	}
	CheckPass__($Tokens,TOKEN_TYPE_CLOSE_CR_BRACKET);	
}


########################################################################################################
########################################## EXTERNAL FUNCTIONS ##########################################
########################################################################################################
############################################## CONSTRUCTOR #############################################
############# Command New #############
#FUNCTION:   Object Constructor - Builds a command
#PARAMATERS: ConfigFileName
#RETURNS:	 Nothing
sub New {
	my $Class = shift;
    my $Self = {
		FileName => shift,			#FILE NAME PROCESSED
		ConfigText => "",			#TEXT OF THE FILE PROVIDED (POST MINOR PROCESSING)	
	};
	bless $Self;

	#POPULATE UNUSED LOOKUP HASHES WITH EMPTY HASH TO PREVENT ERRORS IN FUTURE USAGE
	my %EmptyHash;				   #TEMP HASH USED TO POPULATE UNUSED LOOKUP VARIABLES	
	$Self->ProcessText();
	return $Self;
}

############# PROCESS TEXT #############
#FUNCTION: Opens and processes a config file populating the config data structure.
#PARAMATERS: Config File Name
#RETURNS:	Config Structure
sub ProcessText{
	my $Self = shift;		
	$Self->{FileName} = shift if(scalar(@_)>0);
	my $ConfigText;				#COMPLETE TEXT OF THE CONFIG FILE	
	my $LineNumber=1;			#TRACKING FOR LINE NUMBER FOR ERROR CHECKINGd	
	#OPEN PROVIDED FILE
	
	open(CONFIG, '<:encoding(UTF-8)', $Self->{FileName}) or die ("Cannot open Config File: ".$Self->{FileName});
		while(<CONFIG>){			
			chomp;				
			$ConfigText.='$#$'.$LineNumber.'$#$';
			$LineNumber++;
			$ConfigText.= $_;	#CURRENT LINE BEING PROCESSED
		}
		$ConfigText =~ s/\~$//;
	close(CONFIG);	

	try {
		Parse__(LexConfig__($ConfigText));
		#ParseConfig__(LexConfig__($ConfigText, $Self->{CommandsAvail}));
	}
	catch {
		die "JSON Error: $Self->{FileName}\n\n".$_;
		
	};
}



1;




























